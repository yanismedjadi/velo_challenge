<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ChallengeController;
use App\Http\Controllers\Api\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Retourne les challenges avec créator
Route::get('/challenges', [ChallengeController::class, 'index']);

// Créer un nouvel user
Route::post('/register', [AuthController::class, 'register']);

// Login
Route::post('/login', [AuthController::class, 'login']);

// Profile avec Token
Route::middleware('auth:sanctum')->get('/profile', [AuthController::class, 'profile']);

// Déconnexion avec suppression du Token 
Route::middleware('auth:sanctum')->post('/logout', [AuthController::class, 'logout']);

// Charge les détails d'un challenge
Route::get('/challenges/{id}', [ChallengeController::class, 'show']);

// Créer un nouveau challenge (accessible uniquement au admins)
Route::middleware(['auth:sanctum'])->post('/challenges', [ChallengeController::class, 'store']);


